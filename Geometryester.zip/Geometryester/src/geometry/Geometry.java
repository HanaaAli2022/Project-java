/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometry;

/**
 *
 * @author CoNNect
 */
public class Geometry {

    public static double circleArea(double radius) throws IllegalArgumentException {
        if (radius < 0) {
            throw new IllegalArgumentException("Radius cannot be negative.");
        }
        return Math.PI * radius * radius;
    }

    public static double rectangleArea(double length, double width) throws IllegalArgumentException {
        if (length < 0 || width < 0) {
            throw new IllegalArgumentException("Length and width cannot be negative.");
        }
        return length * width;
    }

    public static double triangleArea(double height, double base) throws IllegalArgumentException {
        if (height < 0 || base < 0) {
            throw new IllegalArgumentException("Height and base cannot be negative.");
        }
        return 0.5 * base * height;
    }
}
