/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometry;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GeometryTester {

    public static void main(String[] args) {
        try (Scanner menuInput = new Scanner(new File("data.txt"));
                PrintWriter output = new PrintWriter("out.txt")) {

            int choice;
            do {
                System.out.println("1. Calculate the Area of a Circle");
                System.out.println("2. Calculate the Area of a Rectangle");
                System.out.println("3. Calculate the Area of a Triangle");
                System.out.println("4. Quit");
                System.out.print("Enter your choice (1-4): ");

                choice = menuInput.nextInt();

                try {
                    switch (choice) {
                        case 1:
                            System.out.print("Enter the radius of the circle: ");
                            double radius = menuInput.nextDouble();
                            double circleArea = Geometry.circleArea(radius);
                            output.println("The area of the circle is " + circleArea);
                            break;
                        case 2:
                            System.out.print("Enter the length of the rectangle: ");
                            double length = menuInput.nextDouble();
                            System.out.print("Enter the width of the rectangle: ");
                            double width = menuInput.nextDouble();
                            double rectangleArea = Geometry.rectangleArea(length, width);
                            output.println("The area of the rectangle is " + rectangleArea);
                            break;
                        case 3:
                            System.out.print("Enter the height of the triangle: ");
                            double height = menuInput.nextDouble();
                            System.out.print("Enter the base of the triangle: ");
                            double base = menuInput.nextDouble();
                            double triangleArea = Geometry.triangleArea(height, base);
                            output.println("The area of the triangle is " + triangleArea);
                            break;
                        case 4:
                            System.out.println("Exiting the program.");
                            break;
                        default:
                            throw new InvalidMenuChoiceException("Invalid choice. Please enter a number from 1-4.");
                    }
                } catch (IllegalArgumentException e) {
                    output.println("Error: " + e.getMessage());
                } catch (InvalidMenuChoiceException e) {
                    output.println("Error: " + e.getMessage());
                }

                System.out.println();  // Print a blank line for readability
            } while (choice != 4);

        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

 class InvalidMenuChoiceException extends Exception {

    public InvalidMenuChoiceException(String message) {
        super(message);
    }
}

